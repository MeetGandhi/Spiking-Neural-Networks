/*
 * mobileSim_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mobileSim".
 *
 * Model version              : 1.53
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Tue Mar 27 21:17:21 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mobileSim.h"
#include "mobileSim_private.h"

/* Block parameters (auto storage) */
P_mobileSim_T mobileSim_P = {
  1.0517647058823543,                  /* Variable: fi_1
                                        * Referenced by: '<S1>/Integrator2'
                                        */
  0.6,                                 /* Variable: omegaL
                                        * Referenced by: '<Root>/Constant1'
                                        */
  1.4,                                 /* Variable: omegaR
                                        * Referenced by: '<Root>/Constant'
                                        */
  10.115512204953218,                  /* Variable: x_1
                                        * Referenced by: '<S1>/Integrator4'
                                        */
  10.050068990960025,                  /* Variable: y_1
                                        * Referenced by: '<S1>/Integrator3'
                                        */
  0.068,                               /* Mask Parameter: Kinmodelvstupuhloverychlosti_L
                                        * Referenced by:
                                        *   '<S1>/Gain'
                                        *   '<S1>/Gain1'
                                        */
  0.024                                /* Mask Parameter: Kinmodelvstupuhloverychlosti_r
                                        * Referenced by:
                                        *   '<S1>/Gain'
                                        *   '<S1>/Gain1'
                                        *   '<S1>/Gain2'
                                        *   '<S1>/Gain3'
                                        */
};
