/*
 * mobileSim.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mobileSim".
 *
 * Model version              : 1.53
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Tue Mar 27 21:17:21 2018
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mobileSim.h"
#include "mobileSim_private.h"

/* Block signals (auto storage) */
B_mobileSim_T mobileSim_B;

/* Continuous states */
X_mobileSim_T mobileSim_X;

/* Block states (auto storage) */
DW_mobileSim_T mobileSim_DW;

/* Real-time model */
RT_MODEL_mobileSim_T mobileSim_M_;
RT_MODEL_mobileSim_T *const mobileSim_M = &mobileSim_M_;

/*
 * This function updates continuous states using the ODE4 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = (ODE4_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 3;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  mobileSim_derivatives();

  /* f1 = f(t + (h/2), y + (h/2)*f0) */
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  mobileSim_step();
  mobileSim_derivatives();

  /* f2 = f(t + (h/2), y + (h/2)*f1) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  mobileSim_step();
  mobileSim_derivatives();

  /* f3 = f(t + h, y + h*f2) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  mobileSim_step();
  mobileSim_derivatives();

  /* tnew = t + h
     ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3) */
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void mobileSim_step(void)
{
  real_T rtb_Gain;
  real_T rtb_Gain1;
  real_T rtb_Gain2;
  real_T rtb_Gain3;
  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* set solver stop time */
    if (!(mobileSim_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&mobileSim_M->solverInfo,
                            ((mobileSim_M->Timing.clockTickH0 + 1) *
        mobileSim_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&mobileSim_M->solverInfo,
                            ((mobileSim_M->Timing.clockTick0 + 1) *
        mobileSim_M->Timing.stepSize0 + mobileSim_M->Timing.clockTickH0 *
        mobileSim_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(mobileSim_M)) {
    mobileSim_M->Timing.t[0] = rtsiGetT(&mobileSim_M->solverInfo);
  }

  /* Integrator: '<S1>/Integrator4' */
  mobileSim_B.Integrator4 = mobileSim_X.Integrator4_CSTATE;
  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* ToWorkspace: '<Root>/To Workspace' */
    if (rtmIsMajorTimeStep(mobileSim_M)) {
      rt_UpdateLogVar((LogVar *)(LogVar*)
                      (mobileSim_DW.ToWorkspace_PWORK.LoggedData),
                      &mobileSim_B.Integrator4, 0);
    }
  }

  /* Integrator: '<S1>/Integrator3' */
  mobileSim_B.Integrator3 = mobileSim_X.Integrator3_CSTATE;
  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* ToWorkspace: '<Root>/To Workspace1' */
    if (rtmIsMajorTimeStep(mobileSim_M)) {
      rt_UpdateLogVar((LogVar *)(LogVar*)
                      (mobileSim_DW.ToWorkspace1_PWORK.LoggedData),
                      &mobileSim_B.Integrator3, 0);
    }
  }

  /* Integrator: '<S1>/Integrator2' */
  mobileSim_B.Integrator2 = mobileSim_X.Integrator2_CSTATE;
  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* ToWorkspace: '<Root>/To Workspace2' */
    if (rtmIsMajorTimeStep(mobileSim_M)) {
      rt_UpdateLogVar((LogVar *)(LogVar*)
                      (mobileSim_DW.ToWorkspace2_PWORK.LoggedData),
                      &mobileSim_B.Integrator2, 0);
    }

    /* Gain: '<S1>/Gain' incorporates:
     *  Constant: '<Root>/Constant'
     */
    rtb_Gain = mobileSim_P.Kinmodelvstupuhloverychlosti_r /
      mobileSim_P.Kinmodelvstupuhloverychlosti_L * mobileSim_P.omegaR;

    /* Gain: '<S1>/Gain1' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    rtb_Gain1 = mobileSim_P.Kinmodelvstupuhloverychlosti_r /
      mobileSim_P.Kinmodelvstupuhloverychlosti_L * mobileSim_P.omegaL;

    /* Sum: '<S1>/Sum' */
    mobileSim_B.Sum = rtb_Gain - rtb_Gain1;
  }

  /* Gain: '<S1>/Gain2' incorporates:
   *  Trigonometry: '<S1>/Trigonometric Function'
   */
  rtb_Gain2 = mobileSim_P.Kinmodelvstupuhloverychlosti_r / 2.0 * sin
    (mobileSim_B.Integrator2);

  /* Gain: '<S1>/Gain3' incorporates:
   *  Trigonometry: '<S1>/Trigonometric Function1'
   */
  rtb_Gain3 = mobileSim_P.Kinmodelvstupuhloverychlosti_r / 2.0 * cos
    (mobileSim_B.Integrator2);

  /* Sum: '<S1>/Sum1' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  Product: '<S1>/Product'
   *  Product: '<S1>/Product1'
   */
  mobileSim_B.Sum1 = mobileSim_P.omegaL * rtb_Gain2 + mobileSim_P.omegaR *
    rtb_Gain2;

  /* Sum: '<S1>/Sum2' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  Product: '<S1>/Product2'
   *  Product: '<S1>/Product3'
   */
  mobileSim_B.Sum2 = mobileSim_P.omegaL * rtb_Gain3 + mobileSim_P.omegaR *
    rtb_Gain3;
  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(mobileSim_M->rtwLogInfo, (mobileSim_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(mobileSim_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(mobileSim_M)!=-1) &&
          !((rtmGetTFinal(mobileSim_M)-(((mobileSim_M->Timing.clockTick1+
               mobileSim_M->Timing.clockTickH1* 4294967296.0)) * 0.05)) >
            (((mobileSim_M->Timing.clockTick1+mobileSim_M->Timing.clockTickH1*
               4294967296.0)) * 0.05) * (DBL_EPSILON))) {
        rtmSetErrorStatus(mobileSim_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&mobileSim_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++mobileSim_M->Timing.clockTick0)) {
      ++mobileSim_M->Timing.clockTickH0;
    }

    mobileSim_M->Timing.t[0] = rtsiGetSolverStopTime(&mobileSim_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.05s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.05, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      mobileSim_M->Timing.clockTick1++;
      if (!mobileSim_M->Timing.clockTick1) {
        mobileSim_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void mobileSim_derivatives(void)
{
  XDot_mobileSim_T *_rtXdot;
  _rtXdot = ((XDot_mobileSim_T *) mobileSim_M->derivs);

  /* Derivatives for Integrator: '<S1>/Integrator4' */
  _rtXdot->Integrator4_CSTATE = mobileSim_B.Sum2;

  /* Derivatives for Integrator: '<S1>/Integrator3' */
  _rtXdot->Integrator3_CSTATE = mobileSim_B.Sum1;

  /* Derivatives for Integrator: '<S1>/Integrator2' */
  _rtXdot->Integrator2_CSTATE = mobileSim_B.Sum;
}

/* Model initialize function */
void mobileSim_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)mobileSim_M, 0,
                sizeof(RT_MODEL_mobileSim_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&mobileSim_M->solverInfo,
                          &mobileSim_M->Timing.simTimeStep);
    rtsiSetTPtr(&mobileSim_M->solverInfo, &rtmGetTPtr(mobileSim_M));
    rtsiSetStepSizePtr(&mobileSim_M->solverInfo, &mobileSim_M->Timing.stepSize0);
    rtsiSetdXPtr(&mobileSim_M->solverInfo, &mobileSim_M->derivs);
    rtsiSetContStatesPtr(&mobileSim_M->solverInfo, (real_T **)
                         &mobileSim_M->contStates);
    rtsiSetNumContStatesPtr(&mobileSim_M->solverInfo,
      &mobileSim_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&mobileSim_M->solverInfo,
      &mobileSim_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&mobileSim_M->solverInfo,
      &mobileSim_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&mobileSim_M->solverInfo,
      &mobileSim_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&mobileSim_M->solverInfo, (&rtmGetErrorStatus
      (mobileSim_M)));
    rtsiSetRTModelPtr(&mobileSim_M->solverInfo, mobileSim_M);
  }

  rtsiSetSimTimeStep(&mobileSim_M->solverInfo, MAJOR_TIME_STEP);
  mobileSim_M->intgData.y = mobileSim_M->odeY;
  mobileSim_M->intgData.f[0] = mobileSim_M->odeF[0];
  mobileSim_M->intgData.f[1] = mobileSim_M->odeF[1];
  mobileSim_M->intgData.f[2] = mobileSim_M->odeF[2];
  mobileSim_M->intgData.f[3] = mobileSim_M->odeF[3];
  mobileSim_M->contStates = ((X_mobileSim_T *) &mobileSim_X);
  rtsiSetSolverData(&mobileSim_M->solverInfo, (void *)&mobileSim_M->intgData);
  rtsiSetSolverName(&mobileSim_M->solverInfo,"ode4");
  rtmSetTPtr(mobileSim_M, &mobileSim_M->Timing.tArray[0]);
  rtmSetTFinal(mobileSim_M, 0.05);
  mobileSim_M->Timing.stepSize0 = 0.05;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    mobileSim_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(mobileSim_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(mobileSim_M->rtwLogInfo, (NULL));
    rtliSetLogT(mobileSim_M->rtwLogInfo, "tout");
    rtliSetLogX(mobileSim_M->rtwLogInfo, "");
    rtliSetLogXFinal(mobileSim_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(mobileSim_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(mobileSim_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(mobileSim_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(mobileSim_M->rtwLogInfo, 1);
    rtliSetLogY(mobileSim_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(mobileSim_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(mobileSim_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &mobileSim_B), 0,
                sizeof(B_mobileSim_T));

  /* states (continuous) */
  {
    (void) memset((void *)&mobileSim_X, 0,
                  sizeof(X_mobileSim_T));
  }

  /* states (dwork) */
  (void) memset((void *)&mobileSim_DW, 0,
                sizeof(DW_mobileSim_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(mobileSim_M->rtwLogInfo, 0.0, rtmGetTFinal
    (mobileSim_M), mobileSim_M->Timing.stepSize0, (&rtmGetErrorStatus
    (mobileSim_M)));

  /* Start for ToWorkspace: '<Root>/To Workspace' */
  {
    int_T dimensions[1] = { 1 };

    mobileSim_DW.ToWorkspace_PWORK.LoggedData = rt_CreateLogVar(
      mobileSim_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(mobileSim_M),
      mobileSim_M->Timing.stepSize0,
      (&rtmGetErrorStatus(mobileSim_M)),
      "x",
      SS_DOUBLE,
      0,
      0,
      0,
      1,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.05,
      1);
    if (mobileSim_DW.ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }

  /* Start for ToWorkspace: '<Root>/To Workspace1' */
  {
    int_T dimensions[1] = { 1 };

    mobileSim_DW.ToWorkspace1_PWORK.LoggedData = rt_CreateLogVar(
      mobileSim_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(mobileSim_M),
      mobileSim_M->Timing.stepSize0,
      (&rtmGetErrorStatus(mobileSim_M)),
      "y",
      SS_DOUBLE,
      0,
      0,
      0,
      1,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.05,
      1);
    if (mobileSim_DW.ToWorkspace1_PWORK.LoggedData == (NULL))
      return;
  }

  /* Start for ToWorkspace: '<Root>/To Workspace2' */
  {
    int_T dimensions[1] = { 1 };

    mobileSim_DW.ToWorkspace2_PWORK.LoggedData = rt_CreateLogVar(
      mobileSim_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(mobileSim_M),
      mobileSim_M->Timing.stepSize0,
      (&rtmGetErrorStatus(mobileSim_M)),
      "fi",
      SS_DOUBLE,
      0,
      0,
      0,
      1,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.05,
      1);
    if (mobileSim_DW.ToWorkspace2_PWORK.LoggedData == (NULL))
      return;
  }

  /* InitializeConditions for Integrator: '<S1>/Integrator4' */
  mobileSim_X.Integrator4_CSTATE = mobileSim_P.x_1;

  /* InitializeConditions for Integrator: '<S1>/Integrator3' */
  mobileSim_X.Integrator3_CSTATE = mobileSim_P.y_1;

  /* InitializeConditions for Integrator: '<S1>/Integrator2' */
  mobileSim_X.Integrator2_CSTATE = mobileSim_P.fi_1;
}

/* Model terminate function */
void mobileSim_terminate(void)
{
  /* (no terminate code required) */
}
